<?php
$servername = "127.0.0.1";
$port = "3307";
$username = "root";
$password = "";
$dbname = "admin_panel_php";

try {
    $pdo = new PDO("mysql:host=$servername;port=$port;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo 'Connection Succefull';
} 
catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

define("BASE_URL","http://localhost/ADMIN_PANEL_PHP/");

define("ADMIN_URL", BASE_URL."admin/");

define("SMTP_HOST","sandbox.smtp.mailtrap.io");
define("SMTP_PORT","2525");
define("SMTP_USERNAME","a16fa6f1fc5db1");
define("SMTP_PASSWORD","b7cf1599c5553f");