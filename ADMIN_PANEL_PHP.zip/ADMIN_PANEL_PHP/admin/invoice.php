
<?php include 'layouts/top.php'?>
<?php include '../config/config.php' ?>
        <div class="main-sidebar">
            <aside id="sidebar-wrapper">
                <div class="sidebar-brand">
                     <a href="<?php echo ADMIN_URL; ?>dashboard.php">Admin Panel</a>
                </div>
                <div class="sidebar-brand sidebar-brand-sm">
                     <a href="<?php echo ADMIN_URL; ?>dashboard.php">Admin Panel</a>
                </div>

                <ul class="sidebar-menu">

                 <li class="<?php if($cur_page == 'dashboard.php') {echo 'active';} ?>"><a class="nav-link" href="<?php echo ADMIN_URL; ?>dashboard.php"><i class="fas fa-hand-point-right"></i> <span>Dashboard</span></a></li>


                <!-- <li class="nav-item dropdown active">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-right"></i><span>Dropdown Items</span></a>
                <ul class="dropdown-menu">
                    <li class="active"><a class="nav-link" href=""><i class="fas fa-angle-right"></i> Item 1</a></li>
                    <li class=""><a class="nav-link" href=""><i class="fas fa-angle-right"></i> Item 2</a></li>
                </ul>
                </li> -->

            <li class="<?php if($cur_page == 'setting.php') {echo 'active';} ?>"><a class="nav-link" href="<?php echo ADMIN_URL; ?>setting.php"><i class="fas fa-hand-point-right"></i> <span>Setting</span></a></li>

            <li class="<?php if($cur_page == 'form.php') {echo 'active';} ?>"><a class="nav-link" href="<?php echo ADMIN_URL; ?>form.php"><i class="fas fa-hand-point-right"></i> <span>Form</span></a></li>

            <li class="<?php if($cur_page == 'table.php') {echo 'active';} ?>"><a class="nav-link" href="<?php echo ADMIN_URL; ?>table.php"><i class="fas fa-hand-point-right"></i> <span>Table</span></a></li>

            <li class="<?php if($cur_page == 'invoice.php') {echo 'active';} ?>"><a class="nav-link" href="<?php echo ADMIN_URL; ?>invoice.php"><i class="fas fa-hand-point-right"></i> <span>Invoice</span></a></li>

                </ul>
            </aside>
        </div>
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Invoice</h1>
                </div>
                <div class="section-body">
                    <div class="invoice">
                        <div class="invoice-print">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="invoice-title">
                                        <h2>Invoice</h2>
                                        <div class="invoice-number">Order #873485</div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <address>
                                                <strong>Invoice To</strong><br>
                                                John Doe<br>
                                                324 SF Street Lane,<br>
                                                NYC, CA, USA, 98346
                                            </address>
                                        </div>
                                        <div class="col-md-6 text-md-right">
                                            <address>
                                                <strong>Invoice Date</strong><br>
                                                February 23, 2022
                                            </address>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <div class="section-title">Order Summary</div>
                                    <p class="section-lead">Here put the order summery notification</p>
                                    <hr class="invoice-above-table">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover table-md">
                                            <tr>
                                                <th>SL</th>
                                                <th>Item Name</th>
                                                <th class="text-center">Price</th>
                                                <th class="text-center">Qty</th>
                                                <th class="text-right">Subtotal</th>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Laptop</td>
                                                <td class="text-center">$100</td>
                                                <td class="text-center">3</td>
                                                <td class="text-right">$300</td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td>Headphone</td>
                                                <td class="text-center">$40</td>
                                                <td class="text-center">2</td>
                                                <td class="text-right">$80</td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="row mt-4">
                                        <div class="col-lg-12 text-right">
                                            <div class="invoice-detail-item">
                                                <div class="invoice-detail-name">Total</div>
                                                <div class="invoice-detail-value invoice-detail-value-lg">$380</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="about-print-button">
                        <div class="text-md-right">
                            <a href="javascript:window.print();" class="btn btn-warning btn-icon icon-left text-white print-invoice-button"><i class="fas fa-print"></i> Print</a>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    </div>

<?php include 'layouts/footer.php'?>
</body>
</html>