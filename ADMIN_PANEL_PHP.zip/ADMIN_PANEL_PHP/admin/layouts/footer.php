  </div>
</div>

<script src="dist-admin/js/scripts.js"></script>
<script src="dist-admin/js/custom.js"></script>
<script>
    const cursor = document.querySelector(".cursor");

    // Show and follow cursor
    document.addEventListener("mousemove", (e) => {
        let x = e.pageX;
        let y = e.pageY;
        cursor.style.top = y + "px";
        cursor.style.left = x + "px";
        cursor.style.display = "block";
    });

    // Hide cursor when the mouse leaves the window
    document.addEventListener("mouseout", () => {
        cursor.style.display = "none";
    });
</script>


</body>
</html>