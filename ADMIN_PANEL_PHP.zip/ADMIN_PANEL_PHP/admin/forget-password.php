<?php include 'layouts/top.php'?>
<?php include '../config/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<?php
  if(isset($_REQUEST['form_forgot_password'])){
       $email = trim($_REQUEST['email']);
       try{
            if($email==''){
                throw new Exception('Email cannot be Empty');
            }
            if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Email is invalid");
            }
            $_SESSION['user_forgot_email']= $email;
            $statement=$pdo->prepare("SELECT * FROM users WHERE email=?");
            $statement->execute([$_REQUEST['email']]);
            $total=$statement->rowCount();
            if(!$total){
                throw new Exception('Email is Not Found');
            }

            $success_message="Please check your email and  follow the instruction to reset the password";
             $token=time();
             $link = ADMIN_URL.'reset-password-verify.php?email='.$_POST['email'].'&token='.$token;
             $email_message = 'Please click on this link to reset you password: <br>';
             $email_message .= '<a href="'.$link.'">';
             $email_message .= 'Reset Password';
             $email_message .= '</a>';

            $mail = new PHPMailer(true);

            try {

                    // Mailtrap Transactional SMTP (not sandbox)

                      $mail->isSMTP();

                      $mail->Host = 'sandbox.smtp.mailtrap.io'; // ✅ Mailtrap sending host

                      $mail->SMTPAuth = true;
                      $mail->SMTPOptions = [

                            'ssl' => [

                            'verify_peer' => false,

                            'verify_peer_name' => false,

                            'allow_self_signed' => true,

                            ],

                      ];
                      $mail->Username = 'a16fa6f1fc5db1'; // 🔁 Replace with Mailtrap sending credentials

                      $mail->Password = 'b7cf1599c5553f'; // 🔁 Replace with Mailtrap sending credentials

                      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

                     $mail->Port = 2525;
                     // From your verified domain
                     $mail->setFrom('info@lankapropert.online'); // ✅ your domain email

                     $mail->addAddress($_REQUEST['email']); // Add a recipient
                     $mail->addReplyTo('contact@example.com');
                     // Optional CC/BCC
                     $mail->addCC('cc@example.com');
                     $mail->addBCC('bcc@example.com');
                     // Email content
                     //$mail->addAttachment('../uploads/DSA.JPG');
                     $mail->isHTML(true);
                     $mail->Subject = 'Reset Your Password';
                     $mail->Body    = $email_message ;
                     $mail->AltBody = 'This is the plain text version of the email.';
                     $mail->send();

             } catch (Exception $e) {

                 echo "❌ Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

}

           
       }
       catch(Exception $e){
         $error_message=$e->getMessage();
       }
  }
?>
        <section class="section">
            <div class="container container-login">
                <div class="row">
                    <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
                        <div class="card card-primary border-box">
                            <div class="card-header card-header-auth">
                                <h4 class="text-center">Forgot Password</h4>
                            </div>
                            <div class="card-body card-body-auth">
                                <?php
                                    if(isset($success_message)){
                                        ?><script>alert("<?php echo $success_message?>")</script><?php
                                    }
                                ?>
                                <form method="POST" action="">
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" placeholder="Email Address" value="" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="form_forgot_password" class="btn btn-primary btn-lg w_100_p">
                                            Submit
                                        </button>
                                    </div>
                                    <div class="form-group">
                                        <div>
                                            <a href="<?php echo ADMIN_URL;?>login.php">Back to Login Page</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php include 'layouts/footer.php'?>