<?php include 'layouts/top.php'?>
<?php include '../config/config.php' ?>
<?php
  if(isset($_REQUEST['form_login'])){
       $password = trim($_REQUEST['password']);
       $confirm_password = trim($_REQUEST['confirmpassword']);
       try{
            if($password==''){
                throw new Exception('password cannot be Empty');
            }
           
            if($confirm_password ==''){
                throw new Exception ('Confirm the password');
            }
            if($password != $confirm_password){
                throw new Exception ('Password does not match');
            }
            if(!isset($_SESSION['user_forgot_email'])){
                throw new Exception ('Email is not found to update the password');
            }
            else{
                $email=$_SESSION['user_forgot_email'];
                $Encrypt_password=password_hash($password,PASSWORD_DEFAULT);
                $statement=$pdo->prepare("update users SET  password=? WHERE email=?");
                $statement->execute([$Encrypt_password,$email]);
                $success_message="Password has been updated successfully";
                unset($_SESSION['user_forgot_email']);
                header('location: '.ADMIN_URL.'login.php');
                
            }

       }
       catch(Exception $e){
         $error_message=$e->getMessage();
       }
  }
?>
        <section class="section">
            <div class="container container-login">
                <div class="row">
                    <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
                        <div class="card card-primary border-box">
                            <div class="card-header card-header-auth">
                                <h4 class="text-center">Reset Password</h4>
                            </div>
                            <div class="card-body card-body-auth">
                                <?php
                                    if(isset($error_message)){
                                        ?><script>alert("<?php echo $error_message?>")</script><?php
                                    }
                                    if(isset($success_message)){
                                        ?><script>alert("<?php echo $success_message?>")</script><?php
                                    }
                                ?>
                                <form method="POST" action="">
                                    <div class="form-group">
                                        <input type="password" class="form-control" name="password" placeholder="New Password" value="" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" name="confirmpassword"  placeholder="Confirm Password">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="form_login" class="btn btn-primary btn-lg w_100_p">
                                           Confirm
                                        </button>
                                    </div>
                                    <div class="form-group">
                                        <div>
                                             <p style="margin-top: 15px; font-size: 14px; color: #777;">Remembered your password?<a href="<?php echo ADMIN_URL;?>login.php">Login here</a></p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php include 'layouts/footer.php'?>