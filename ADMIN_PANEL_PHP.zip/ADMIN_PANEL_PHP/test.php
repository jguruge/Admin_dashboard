<?php
// Simulating registration - hashing the password
$plainPassword = "24101186Kcaco#800";
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);
echo "Hashed Password: " . $hashedPassword . "<br>";
?>



